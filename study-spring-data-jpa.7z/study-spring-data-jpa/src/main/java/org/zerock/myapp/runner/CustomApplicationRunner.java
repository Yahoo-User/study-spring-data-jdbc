package org.zerock.myapp.runner;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;


//@Log4j2
@Slf4j

@NoArgsConstructor

@Component("customApplicationRunner")
public class CustomApplicationRunner
    implements ApplicationRunner, InitializingBean, DisposableBean {


    @Override
    public void afterPropertiesSet() { // 전처리
        log.trace("afterPropertiesSet() invoked.");

    } // afterPropertiesSet

    @Override
    public void destroy() {    // 후처리
        log.trace("destroy() invoked.");

    } // destroy

    @Override
    public void run(ApplicationArguments args) {
        log.trace("run({}) invoked.", args);

    } // run
} // end class


