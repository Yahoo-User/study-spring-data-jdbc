package org.zerock.myapp.runner;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.transaction.Transactional;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;


//@Log4j2
@Slf4j

@NoArgsConstructor

@Component("customCmdLineRunner")
public class CustomCmdLineRunner implements CommandLineRunner {


    @PostConstruct
    void postConstruct() {  // 전처리 초기화
        log.trace("postConstruct() invoked.");
    } // postConstruct

    @PreDestroy
    void preDestroy() {     // 후처리
        log.trace("preDestroy() invoked.");
    } // preDestroy

    @Transactional
    @Override
    public void run(String... args) {
        log.trace("run({}) invoked.", Arrays.toString(args));
    } // run

} // end class


